<?php
// Sends all saved students to the frontend as JSON
require "config.php";

$students = load_students();

foreach ($students as &$s) {
    $s["grade"] = grade($s["marks"]);
}
unset($s);

$average = count($students) ? round(array_sum(array_column($students, "marks")) /
count($students), 1) : 0;

echo json_encode([
    "count"     => count($students),
    "average"   => $average,
    "students"  => $students,
]);
```[cite: 7]

---

### `backend/data/students.json` (Starting Data)
```json
[
    { "enrollment": "A001", "name": "Aarav Sharma", "email": "aarav@example.com", "course": "B.Tech CSE", "gender": "Male", "marks": 88 },
    { "enrollment": "A002", "name": "Diya Patel", "email": "diya@example.com", "course": "BCA", "gender": "Female", "marks": 92 },
    { "enrollment": "A003", "name": "Rohan Gupta", "email": "rohan@example.com", "course": "MCA", "gender": "Male", "marks": 75 },
    { "enrollment": "A004", "name": "Sara Khan", "email": "sara@example.com", "course": "B.Sc IT", "gender": "Female", "marks": 81 }
]
```[cite: 7]